package com.atradius.ncm;

import static org.junit.Assert.*;
import java.awt.image.RenderedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.internal.TextListener;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.hp.lft.unittesting.OutputParameters;
import com.hp.lft.unittesting.datadriving.ALM;
import com.atradius.ncm.AtriumLoginException;
import com.atradius.ncm.LeanFtTest;
import com.atradius.unittesting.*;
import com.hp.lft.report.Reporter;
import com.hp.lft.report.Status;
import com.hp.lft.verifications.Verify;
import com.hp.lft.unittesting.datadriving.ALM;
import com.hp.lft.unittesting.datadriving.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.hp.lft.sdk.*;
import com.hp.lft.verifications.*;
import com.hp.lft.sdk.utils.*;

@SuppressWarnings("unused")
@RunWith(Parameterized.class)
public class LeanFtTest extends UnitTestClassBase {
	public static String username;
	public static String password;
	
	@Parameters(name = "iteration: {index}; username={0}")
	public static Iterable<String[]> data() throws Exception {
					return getAlmData();
			}

	
	public LeanFtTest(@ALM(parameter = "username") String In_User_id, @ALM(parameter = "Password") String In_Pass) {
		password = In_Pass;
		username = In_User_id;
	}

	
	
	public static void main(String[] args) {
		JUnitCore junit = new JUnitCore();
		junit.addListener(new TextListener(System.out));

		
		
		Result result = junit.run(LeanFtTest.class); // Replace "SampleTest" with the name of your class
		if (result.getFailureCount() > 0) {
			System.out.println("Test failed.");
			System.exit(1);
		} else {
			System.out.println("Test finished successfully.");
			System.exit(0);
		}
		
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		AlmRunInfo almRunInfo = AlmUtils.getAlmRunInfo();
		if (almRunInfo != null) {
			BusinessComponentRunInfo bcRunInfo = almRunInfo.getBusinessComponentRunInfo();
			instance = new LeanFtTest(username, password);
			globalSetup(LeanFtTest.class);
		}else
		{
			username = "INBSUG1";
			password = "Shailesh";
		}
		

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		globalTearDown();
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	public String Out_UserID;
	public boolean Out_bFlag;

	@Test
	@OutputParameters({ "Out_UserID", "Out_bFlag" })
	public void test() throws Exception {

		
		
		Out_bFlag = true;
		if (username.isEmpty()) {
			username = "ABC";
		}
		if (password.isEmpty()) {
			password = "ABC";
		}
		Out_UserID = username;
		Reporter.reportEvent("Login Details", "UserName: " + username + " Password: " + password);
		System.setProperty("webdriver.chrome.driver", "C:/Web Drivers/chromedriver.exe");
		// System.setProperty("webdriver.firefox.driver","C:\\Users\\INBSUG1\\Desktop\\Drivers\\geckodriver.exe");
		WebDriver browser = new ChromeDriver();
		RenderedImage Img = null;
		// String Screenshotpath = null;
		try {

			// Navigate to "Atradius Portal"
			browser.get("https://portaluat.atradius.com");
			browser.manage().window().maximize();
			// Wait until page loads
			// browser.wait(5);

			// Capture Screenshot
			Img = (RenderedImage) ImageIO
					.read(new File(((TakesScreenshot) browser).getScreenshotAs(OutputType.FILE).getAbsolutePath()));

			// Verify Home page title and when not found throw exception
			if (!Verify.isTrue(browser.getTitle().equals("Welcome to Atradius"))) {
				Out_bFlag = false;
				throw new AtriumLoginException("Atrium Login Page Not Found");
			}

			Reporter.reportEvent("Atrium Login", "Atrium Login Page available", Status.Passed, Img);

			// Login to Atrium
			browser.findElement(By.id("username")).sendKeys(username);
			browser.findElement(By.id("password")).sendKeys(password);
			browser.findElement(By.id("login")).click();
			// File scrFile = ((TakesScreenshot) browser).getScreenshotAs(OutputType.FILE);
			// String screenShotPath = GetScreenShot.capture(browser, "login");
			Img = (RenderedImage) ImageIO
					.read(new File(((TakesScreenshot) browser).getScreenshotAs(OutputType.FILE).getAbsolutePath()));

			if (!Verify.isTrue(browser.getTitle().equals("Home"))) {
				Out_bFlag = false;
				if (browser.findElement(com.hpe.leanft.selenium.By.className("error_message")).getText().trim()
						.equals("You have entered an incorrect Login ID or password. Please check and try again.")) {
					throw new AtriumLoginException("Invlaid Credentials");
				} else {
					throw new AtriumLoginException("Login Failed");
				}
			}

			Reporter.reportEvent("Atrium Login", "Login SucessFull", Status.Passed, Img);

		} catch (AtriumLoginException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
			switch (e.getMessage()) {
			case "Atrium Login Page Not Found":
				Reporter.reportEvent("Atrium Login", "Atrium Login Page Not Found", Status.Failed, Img);
				break;
			case "Login Failed":
				Reporter.reportEvent("Atrium Login", "Cannot login to Atrium home page. login Failed", Status.Failed,
						Img);
				break;
			case "Invlaid Credentials":
				Reporter.reportEvent("Atrium Login", "Invalid Credentials", Status.Failed, Img);
				break;
			default:
				Reporter.reportEvent("Atrium Login", "Atrium Login Page Not found", Status.Failed, e);
				break;
			}

			throw e;
		} catch (Exception e) {
			Reporter.reportEvent("Exception", "Test failed", Status.Failed, e);
			throw e;
		}
		// Launch Chrome
		finally {
			// Close the browser
			browser.close();
		}

	}

}
