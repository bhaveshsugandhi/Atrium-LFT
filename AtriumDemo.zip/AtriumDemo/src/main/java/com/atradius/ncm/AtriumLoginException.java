package com.atradius.ncm;

public class AtriumLoginException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AtriumLoginException(String message) {
		super(message);
	}

}
